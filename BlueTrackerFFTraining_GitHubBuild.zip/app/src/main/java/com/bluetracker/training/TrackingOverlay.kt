package com.bluetracker.training

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

class TrackingOverlay(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF168BFF.toInt()
        strokeWidth = 6f
        style = Paint.Style.STROKE
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF168BFF.toInt()
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private var target: RectF? = null
    private var sourceWidth = 1
    private var sourceHeight = 1

    fun setTarget(left: Float, top: Float, right: Float, bottom: Float, w: Int, h: Int) {
        sourceWidth = w.coerceAtLeast(1)
        sourceHeight = h.coerceAtLeast(1)
        target = RectF(left, top, right, bottom)
        invalidate()
    }

    fun clearTarget() {
        target = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val t = target ?: return

        // FIT_CENTER mapping, matching PreviewView's display behavior.
        val scale = min(width.toFloat() / sourceWidth, height.toFloat() / sourceHeight)
        val dx = (width - sourceWidth * scale) / 2f
        val dy = (height - sourceHeight * scale) / 2f

        val rect = RectF(
            dx + t.left * sourceWidth * scale,
            dy + t.top * sourceHeight * scale,
            dx + t.right * sourceWidth * scale,
            dy + t.bottom * sourceHeight * scale
        )
        val centerX = width / 2f
        val centerY = height / 2f
        canvas.drawLine(centerX, centerY, rect.centerX(), rect.centerY(), linePaint)
        canvas.drawRoundRect(rect, 16f, 16f, boxPaint)
    }
}
