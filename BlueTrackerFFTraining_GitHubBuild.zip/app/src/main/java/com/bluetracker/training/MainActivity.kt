package com.bluetracker.training

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: TrackingOverlay
    private lateinit var status: TextView
    private lateinit var cameraExecutor: ExecutorService
    private val detector by lazy {
        val options = PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
        PoseDetection.getClient(options)
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else status.text = "Permiso de cámara necesario"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
        overlay = TrackingOverlay(this)
        status = TextView(this).apply {
            text = "BLUE TRACKER • entrenamiento"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(24, 32, 24, 16)
            setBackgroundColor(0x99071426.toInt())
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(status, FrameLayout.LayoutParams(-1, -2))
        setContentView(root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val mediaImage = imageProxy.image
                if (mediaImage == null) {
                    imageProxy.close()
                    return@setAnalyzer
                }
                val rotation = imageProxy.imageInfo.rotationDegrees
                val input = InputImage.fromMediaImage(mediaImage, rotation)
                val rotatedWidth = if (rotation == 90 || rotation == 270)
                    imageProxy.height else imageProxy.width
                val rotatedHeight = if (rotation == 90 || rotation == 270)
                    imageProxy.width else imageProxy.height

                detector.process(input)
                    .addOnSuccessListener { pose ->
                        val points = pose.allPoseLandmarks
                        if (points.isNotEmpty()) {
                            val xs = points.map { it.position.x }
                            val ys = points.map { it.position.y }
                            val left = (xs.minOrNull() ?: 0f) / rotatedWidth
                            val right = (xs.maxOrNull() ?: 0f) / rotatedWidth
                            val top = (ys.minOrNull() ?: 0f) / rotatedHeight
                            val bottom = (ys.maxOrNull() ?: 0f) / rotatedHeight
                            runOnUiThread {
                                overlay.setTarget(left, top, right, bottom, rotatedWidth, rotatedHeight)
                                status.text = "Objetivo visible detectado • cámara local"
                            }
                        } else {
                            runOnUiThread {
                                overlay.clearTarget()
                                status.text = "Buscando una persona visible…"
                            }
                        }
                    }
                    .addOnFailureListener {
                        runOnUiThread { status.text = "No se pudo analizar la imagen" }
                    }
                    .addOnCompleteListener { imageProxy.close() }
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
            } catch (e: Exception) {
                status.text = "No se pudo iniciar la cámara"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        detector.close()
    }
}
