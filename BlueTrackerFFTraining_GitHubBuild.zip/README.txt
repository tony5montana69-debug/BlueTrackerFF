BLUE TRACKER TRAINING — proyecto inicial Android

Qué hace:
- Abre la cámara trasera del teléfono.
- Usa ML Kit Pose Detection para detectar una persona visible en el campo de la cámara.
- Dibuja un recuadro y una línea azul desde el centro de la vista hacia la persona.
- El procesamiento se realiza localmente en el teléfono; no se envían imágenes a un servidor.

Importante:
- Esta app NO se conecta a Free Fire, no lee su pantalla ni detecta enemigos dentro del juego.
- Es una demostración de seguimiento visual con la cámara del teléfono.
- El proyecto es código fuente; todavía NO es un APK compilado.

Para compilar:
1. Abre el proyecto en Android Studio o en un entorno Android compatible.
2. Espera a que Gradle descargue las dependencias.
3. Compila la variante debug.
4. Instala el APK generado en app/build/outputs/apk/debug/.

Requisitos:
- Android SDK 35 y JDK 17 para compilar.
- Android 6.0 o superior para instalar.
- Concede permiso de cámara al abrir.

Nota: este proyecto inicial puede requerir ajustes según la versión del entorno Android usado para compilar.
